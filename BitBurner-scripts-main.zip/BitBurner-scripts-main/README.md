# BitBurner-scripts
My BitBurner scripts
